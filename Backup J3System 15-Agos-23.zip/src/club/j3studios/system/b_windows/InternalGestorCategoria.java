package club.j3studios.system.b_windows;

import java.awt.Dimension;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;

import club.j3studios.system.control.Ctrl_Category;
import club.j3studios.system.database.SQL;
import club.j3studios.system.model.Categoria;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InternalGestorCategoria extends JInternalFrame {

	private static final long serialVersionUID = 1L;
	
	private Integer idCategoria;

	private JTextField textField;
	public static JTable table;
	public static JScrollPane scrollPane;
	
	public InternalGestorCategoria() {
		initComponents();
		
		setBorder(null);
		setClosable(true);
		setResizable(false);
		setSize(new Dimension(600, 400));
		setTitle("GESTOR DE CATEGORIAS � J3Studios.net");
		getContentPane().setLayout(null);
		
		this.loadTableCategories();
	}
	
	private void initComponents() {
		JLabel lblNewLabel_1 = new JLabel("CATEGOR\u00CDAS");
		lblNewLabel_1.setFont(new Font("MADE TOMMY", Font.BOLD, 16));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(10, 11, 580, 26);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("MODIFICAR NOMBRE");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(397, 197, 193, 31);
		getContentPane().add(lblNewLabel_2);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_2.setBounds(397, 229, 193, 45);
		getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(0, 0, 193, 45);
		panel_2.add(textField);
		textField.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.setBounds(397, 48, 193, 125);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton = new JButton("ACTUALIZAR");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!textField.getText().isEmpty()) {
					Categoria categoria = new Categoria();
					Ctrl_Category cc = new Ctrl_Category();
					
					categoria.setDescripcion(textField.getText().trim());
					if (cc.updateCategory(categoria, idCategoria)) {
						JOptionPane.showMessageDialog(null, "Categoria Actualizada.");
						textField.setText("");
						loadTableCategories();
					} else {
						JOptionPane.showMessageDialog(null, "Error al Actualizar la Categoria");
					}
				} else {
					JOptionPane.showMessageDialog(null, "Selecciona una categoria.");
				}
			}
		});
		btnNewButton.setBackground(new Color(0, 255, 153));
		btnNewButton.setFont(new Font("Lucida Sans", Font.BOLD, 16));
		btnNewButton.setBounds(10, 11, 173, 49);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("ELIMINAR");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!textField.getText().isEmpty()) {
					Ctrl_Category cc = new Ctrl_Category();
					
					if (!cc.deleteCategory(idCategoria)) {
						JOptionPane.showMessageDialog(null, "Categoria " + textField.getText().trim() + " Eliminada.");
						textField.setText("");
						loadTableCategories();
					} else {
						JOptionPane.showMessageDialog(null, "Error al Eliminar la Categoria");
					}
					
				} else {
					JOptionPane.showMessageDialog(null, "Selecciona una categoria.");
				}
			}
		});
		btnNewButton_1.setBackground(new Color(255, 102, 102));
		btnNewButton_1.setFont(new Font("Lucida Sans", Font.BOLD, 16));
		btnNewButton_1.setBounds(10, 65, 173, 49);
		panel_1.add(btnNewButton_1);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel.setBounds(10, 48, 377, 314);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 357, 292);
		panel.add(scrollPane);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(InternalGestorCategoria.class.getResource("/images/fondo3.jpg")));
		lblNewLabel.setBounds(0, 0, 600, 373);
		getContentPane().add(lblNewLabel);
	}
	
	/*
	 * Method showing all categories
	 * 
	 * 
	 */
	
	private void loadTableCategories() {
		Connection con = SQL.conectar();
		DefaultTableModel model = new DefaultTableModel();
		String sql = "select idCategoria, descripcion from tb_categoria";
		Statement st;
		
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			InternalGestorCategoria.table = new JTable(model);
			InternalGestorCategoria.scrollPane.setViewportView(InternalGestorCategoria.table);
			
			model.addColumn("idCategoria");
			model.addColumn("descripcion");
			
			while(rs.next()) {
				Object fila[] = new Object[2];
				for (int i = 0; i < 2; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				model.addRow(fila);
			}
			con.close();
		} catch (SQLException e) {
			System.out.print("Error al llenar la tabla de categorias.");
		}
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Integer fila_point = table.rowAtPoint(e.getPoint());
				Integer columna_point = 0;
				
				if (fila_point >= -1) {
					idCategoria = (Integer)model.getValueAt(fila_point, columna_point);
					sendDataCategorySelected(idCategoria);
				} 
			}

		});
	}
	

	private void sendDataCategorySelected(Integer idCategoria) {
		try {
			Connection con = SQL.conectar();
			PreparedStatement pst = con.prepareStatement("select * from tb_categoria where idCategoria = '" + idCategoria + "'");
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				textField.setText(rs.getString("descripcion"));
			}
			con.close();
		} catch (SQLException e) {
			System.out.print("Error al seleccionar la categoria.");
		}
	}
}
