package club.j3studios.system.b_windows;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import club.j3studios.system.control.Ctrl_Category;
import club.j3studios.system.model.Categoria;

public class InternalCategoria extends JInternalFrame {

	private static final long serialVersionUID = -7238391127369470418L;
	private JTextField textCategoryName;
	
	public InternalCategoria() {
		setBorder(null);
		setClosable(true);
		setResizable(false);
		setSize(new Dimension(385, 195));
		setTitle("NUEVA CATEGORIA � J3Studios.net");
		getContentPane().setLayout(null);
		
		JButton Boton = new JButton("Crear categor\u00EDa");
		Boton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Categoria category = new Categoria();
				Ctrl_Category ctrlCategory = new Ctrl_Category();
				
				category.setDescripcion(textCategoryName.getText().trim());
				if (!textCategoryName.getText().isEmpty()) {
					if (!ctrlCategory.existCategory(textCategoryName.getText())) {
						if (ctrlCategory.saveCategory(category)) {
							JOptionPane.showMessageDialog(null, "Se ha guardado correctamente la categor�a: " + textCategoryName.getText().trim());
							dispose();
						} else {
							JOptionPane.showMessageDialog(null, "Se present� un error al guardar la categor�a: " + textCategoryName.getText().trim());
						}
					} else {
						JOptionPane.showMessageDialog(null, "Ya existe la categor�a: " + textCategoryName.getText().trim());
					}
				} else {
					JOptionPane.showMessageDialog(null, "El campo de la categor�a est� vac�o.");
				}				
				textCategoryName.setText("");
			}
		});
		Boton.setFont(new Font("Tahoma", Font.BOLD, 14));
		Boton.setBorder(new EmptyBorder(0, 0, 0, 0));
		Boton.setBounds(128, 107, 130, 41);
		getContentPane().add(Boton);
		
		textCategoryName = new JTextField();
		textCategoryName.setBorder(null);
		textCategoryName.setToolTipText("Nombre de la categor\u00EDa");
		textCategoryName.setHorizontalAlignment(SwingConstants.CENTER);
		textCategoryName.setBounds(95, 55, 194, 34);
		getContentPane().add(textCategoryName);
		textCategoryName.setColumns(10);
		
		JLabel newCategory = new JLabel("NUEVA CATEGOR\u00CDA");
		newCategory.setFont(new Font("MADE TOMMY", Font.BOLD, 20));
		newCategory.setHorizontalAlignment(SwingConstants.CENTER);
		newCategory.setForeground(new Color(255, 255, 255));
		newCategory.setBounds(10, 10, 364, 34);
		getContentPane().add(newCategory);
		
		JLabel wallpaper = new JLabel("");
		wallpaper.setIcon(new ImageIcon(InternalCategoria.class.getResource("/images/fondo3.jpg")));
		wallpaper.setBounds(0, -28, 384, 211);
		getContentPane().add(wallpaper);
	}
}
