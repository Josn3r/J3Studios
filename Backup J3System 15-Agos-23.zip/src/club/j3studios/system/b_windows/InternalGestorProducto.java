package club.j3studios.system.b_windows;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;

import club.j3studios.system.control.Ctrl_Producto;
import club.j3studios.system.database.SQL;
import club.j3studios.system.model.Producto;

public class InternalGestorProducto extends JInternalFrame {

	private static final long serialVersionUID = 1L;
	
	private int idProducto;
    int obtenerIdCategoriaCombo = 0;

	public static JTable table;
	public static JScrollPane scrollPane;
	
	private JTextField textCodigo;
	private JTextField textNombre;
	private JTextField textPrecioCosto;
	private JTextField textGanancias;
	private JTextField textStock;
	private JTextField textPrecioVenta;
	private JTextField textEditIva;
	@SuppressWarnings("rawtypes")
	private JComboBox comboBox;
	
	public InternalGestorProducto() {
		initComponents();
		
		setBorder(null);
		setClosable(true);
		setResizable(false);
		setSize(new Dimension(900, 500));
		setTitle("GESTOR DE PRODUCTOS � J3Studios.net");
		getContentPane().setLayout(null);
		
		this.loadAllCategories();
		this.loadTableCategories();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void initComponents() {
		JLabel lblNewLabel_1 = new JLabel("PRODUCTOS");
		lblNewLabel_1.setFont(new Font("MADE TOMMY", Font.BOLD, 28));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(10, 0, 890, 37);
		getContentPane().add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 353, 880, 109);
		getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("C\u00F3digo:");
		lblNewLabel_2.setForeground(new Color(51, 51, 51));
		lblNewLabel_2.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 11, 60, 30);
		panel_2.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Nombre:");
		lblNewLabel_2_1.setForeground(new Color(51, 51, 51));
		lblNewLabel_2_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel_2_1.setBounds(10, 67, 60, 30);
		panel_2.add(lblNewLabel_2_1);
		
		textCodigo = new JTextField();
		textCodigo.setBounds(72, 11, 130, 30);
		panel_2.add(textCodigo);
		textCodigo.setColumns(10);
		
		textNombre = new JTextField();
		textNombre.setColumns(10);
		textNombre.setBounds(72, 68, 130, 30);
		panel_2.add(textNombre);
		
		JLabel lblNewLabel_2_2 = new JLabel("Tipo de Venta:");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2.setForeground(new Color(51, 51, 51));
		lblNewLabel_2_2.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel_2_2.setBounds(212, 11, 130, 30);
		panel_2.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Precio de Costo:");
		lblNewLabel_2_1_1.setForeground(new Color(51, 51, 51));
		lblNewLabel_2_1_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel_2_1_1.setBounds(352, 11, 117, 30);
		panel_2.add(lblNewLabel_2_1_1);
		
		textPrecioCosto = new JFormattedTextField(new DecimalFormat("#0.00"));
		textPrecioCosto.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();
		        if((Character.isDigit(c))||(c==KeyEvent.VK_PERIOD)||(c==KeyEvent.VK_DECIMAL)||(c==KeyEvent.VK_COMMA)||(c==KeyEvent.VK_BACK_SPACE)){
		            if(c==KeyEvent.VK_PERIOD) { 
		            	String s=textPrecioCosto.getText();
		            	int dot=s.indexOf('.');
		            	if(dot!=-1){
		            		getToolkit().beep();
		            		e.consume();
		            	}
		            }
		        }else{    
		            getToolkit().beep();
		            e.consume();
		        }
		        
				if (textPrecioCosto.getText().isEmpty()) {
					return;
				}
				String costoTXT = textPrecioCosto.getText().trim();
				Double precioCosto = 0.0;
				boolean aux = false;
				for (int i = 0; i<costoTXT.length(); i++) {
					if (costoTXT.charAt(i) == ',') {
						String precioNuevo = costoTXT.replace(",", ".");
						precioCosto = Double.parseDouble(precioNuevo);
						aux = true;
					}
				}								
				if (aux == true) {
					Double ganancias = 0.0;
					if (isDouble(textGanancias.getText().trim())) {
						ganancias = Double.valueOf(textGanancias.getText().trim());
					}
					Double porcentaje = calcPercent(precioCosto, ganancias);
					Double precioVenta = precioCosto + porcentaje;
					
					DecimalFormat format = new DecimalFormat("#0.00");
					String precioForVenta = format.format(precioVenta);					
					textPrecioVenta.setText(precioForVenta);
				} else {
					precioCosto = Double.parseDouble(textPrecioCosto.getText().trim());
					Double ganancias = 0.0;
					if (isDouble(textGanancias.getText().trim())) {
						ganancias = Double.valueOf(textGanancias.getText().trim());
					}
					Double porcentaje = calcPercent(precioCosto, ganancias);
					Double precioVenta = precioCosto + porcentaje;
					
					DecimalFormat format = new DecimalFormat("#0.00");
					String precioForVenta = format.format(precioVenta);					
					textPrecioVenta.setText(precioForVenta);
				}
			}
		});
		textPrecioCosto.setColumns(10);
		textPrecioCosto.setBounds(465, 17, 92, 20);
		panel_2.add(textPrecioCosto);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Ganancia:");
		lblNewLabel_2_2_1.setForeground(new Color(51, 51, 51));
		lblNewLabel_2_2_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel_2_2_1.setBounds(352, 40, 70, 30);
		panel_2.add(lblNewLabel_2_2_1);
		
		textGanancias = new JTextField();
		textGanancias.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();
		        if((Character.isDigit(c))||(c==KeyEvent.VK_PERIOD)||(c==KeyEvent.VK_BACK_SPACE)){
		            if(c==KeyEvent.VK_PERIOD) { 
		            	String s=textGanancias.getText();
		            	int dot=s.indexOf('.');
		            	if(dot!=-1){
		            		getToolkit().beep();
		            		e.consume();
		            	}
		            }
		        }else{    
		            getToolkit().beep();
		            e.consume();
		        }
		        
		        if (textPrecioCosto.getText().isEmpty()) {
					return;
				}
				String costoTXT = textPrecioCosto.getText().trim();
				Double precioCosto = 0.0;
				boolean aux = false;
				for (int i = 0; i<costoTXT.length(); i++) {
					if (costoTXT.charAt(i) == ',') {
						String precioNuevo = costoTXT.replace(",", ".");
						precioCosto = Double.parseDouble(precioNuevo);
						aux = true;
					}
				}								
				if (aux == true) {
					Double ganancias = 0.0;
					if (isDouble(textGanancias.getText().trim())) {
						ganancias = Double.valueOf(textGanancias.getText().trim());
					}
					Double porcentaje = calcPercent(precioCosto, ganancias);
					Double precioVenta = precioCosto + porcentaje;
					
					DecimalFormat format = new DecimalFormat("#0.00");
					String precioForVenta = format.format(precioVenta);					
					textPrecioVenta.setText(precioForVenta);
				} else {
					precioCosto = Double.parseDouble(textPrecioCosto.getText().trim());
					Double ganancias = 0.0;
					if (isDouble(textGanancias.getText().trim())) {
						ganancias = Double.valueOf(textGanancias.getText().trim());
					}
					Double porcentaje = calcPercent(precioCosto, ganancias);
					Double precioVenta = precioCosto + porcentaje;
					
					DecimalFormat format = new DecimalFormat("#0.00");
					String precioForVenta = format.format(precioVenta);					
					textPrecioVenta.setText(precioForVenta);
				}
			}
		});
		textGanancias.setColumns(10);
		textGanancias.setBounds(420, 46, 137, 20);
		panel_2.add(textGanancias);
		
		JLabel lblNewLabel_2_2_1_1 = new JLabel("Categor\u00EDa");
		lblNewLabel_2_2_1_1.setForeground(new Color(51, 51, 51));
		lblNewLabel_2_2_1_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel_2_2_1_1.setBounds(567, 11, 70, 30);
		panel_2.add(lblNewLabel_2_2_1_1);
		
		JLabel lblNewLabel_2_1_1_1_1 = new JLabel("Cantidad:");
		lblNewLabel_2_1_1_1_1.setForeground(new Color(51, 51, 51));
		lblNewLabel_2_1_1_1_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel_2_1_1_1_1.setBounds(567, 67, 70, 30);
		panel_2.add(lblNewLabel_2_1_1_1_1);
		
		textStock = new JTextField();
		textStock.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();
		        if (!(Character.isDigit(c)||c==KeyEvent.VK_BACK_SPACE)){
		        	getToolkit().beep();
		            e.consume();
		        }
			}
		});
		textStock.setColumns(10);
		textStock.setBounds(635, 68, 60, 30);
		panel_2.add(textStock);
		
		chckbxUnitario = new JCheckBox("Unitario");
		chckbxUnitario.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (chckbxUnitario.isSelected()) {
					if (chckbxKilogramos.isSelected()) {
						chckbxKilogramos.setSelected(false);
					}
				} else {
					if (!chckbxKilogramos.isSelected()) {
						chckbxKilogramos.setSelected(true);
					}
				}
			}
		});
		chckbxUnitario.setBounds(222, 40, 97, 25);
		panel_2.add(chckbxUnitario);
		
		chckbxKilogramos = new JCheckBox("Kilogramos");
		chckbxKilogramos.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if (chckbxKilogramos.isSelected()) {
					if (chckbxUnitario.isSelected()) {
						chckbxUnitario.setSelected(false);
					}
				} else {
					if (!chckbxUnitario.isSelected()) {
						chckbxUnitario.setSelected(true);
					}
				}
			}
		});
		chckbxKilogramos.setBounds(222, 71, 97, 25);
		panel_2.add(chckbxKilogramos);
		
		textPrecioVenta = new JFormattedTextField(new DecimalFormat("#0.00"));
		textPrecioVenta.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();
		        if((Character.isDigit(c))||(c==KeyEvent.VK_PERIOD)||(c==KeyEvent.VK_DECIMAL)||(c==KeyEvent.VK_COMMA)||(c==KeyEvent.VK_BACK_SPACE)){
		            if(c==KeyEvent.VK_PERIOD||c==KeyEvent.VK_DECIMAL||c==KeyEvent.VK_COMMA) { 
		            	String s=textPrecioVenta.getText();
		            	int dot=s.indexOf('.');
		            	if(dot!=-1){
		            		getToolkit().beep();
		            		e.consume();
		            	}
		            }
		        }else{    
		            getToolkit().beep();
		            e.consume();
		        }
			}
		});
		textPrecioVenta.setColumns(10);
		textPrecioVenta.setBounds(465, 74, 92, 20);
		panel_2.add(textPrecioVenta);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("Precio de Venta:");
		lblNewLabel_2_1_1_1.setForeground(new Color(51, 51, 51));
		lblNewLabel_2_1_1_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel_2_1_1_1.setBounds(352, 68, 117, 30);
		panel_2.add(lblNewLabel_2_1_1_1);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"-- Seleccionar --"}));
		comboBox.setBounds(635, 12, 130, 30);
		panel_2.add(comboBox);
		
		JLabel lblNewLabel_2_1_1_1_1_1 = new JLabel("IVA:");
		lblNewLabel_2_1_1_1_1_1.setForeground(new Color(51, 51, 51));
		lblNewLabel_2_1_1_1_1_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel_2_1_1_1_1_1.setBounds(742, 67, 70, 30);
		panel_2.add(lblNewLabel_2_1_1_1_1_1);
		
		textEditIva = new JTextField();
		textEditIva.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c=e.getKeyChar();
		        if (!(Character.isDigit(c)||c==KeyEvent.VK_BACK_SPACE)){
		        	getToolkit().beep();
		            e.consume();
		        }
			}
		});
		textEditIva.setColumns(10);
		textEditIva.setBounds(778, 68, 92, 30);
		panel_2.add(textEditIva);
		
		chckbxExento = new JCheckBox("Exento");
		chckbxExento.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxExento.setBounds(742, 45, 128, 23);
		panel_2.add(chckbxExento);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.setBounds(697, 39, 193, 125);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton = new JButton("ACTUALIZAR");
		/*btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Producto producto = new Producto();
				Ctrl_Producto ctrlProducto = new Ctrl_Producto();
				
				String tipoDeVenta = "";
				String categoria = "";
				Boolean exento = true;
				Integer iva = 16;				
				if (chckbxKilogramos.isSelected()) {
					tipoDeVenta = "KILOGRAMOS";
				} else {
					tipoDeVenta = "UNITARIO";
				}				
				if (!chckbxExento.isSelected()) {
					exento = false;
					iva = Integer.valueOf(textEditIva.getText().trim());
				}				
				categoria = comboBox.getSelectedItem().toString().trim();				
				
				if (textCodigo.getText().isEmpty() || textNombre.getText().isEmpty() || textPrecioCosto.getText().isEmpty() || textGanancias.getText().isEmpty() || textPrecioVenta.getText().isEmpty() || textStock.getText().isEmpty() || textEditIva.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Por favor, complete los campos necesarios.");
				} else {
					if (ctrlProducto.existProductoByCode(textCodigo.getText().trim())) {
						String pExistente = ctrlProducto.getExistProductoByCode(textCodigo.getText().trim());
						String codigo = textCodigo.getText().trim();
						if (pExistente.equals(codigo)) {
							if (categoria.equals("-- Seleccionar --")) {
								JOptionPane.showMessageDialog(null, "Debes seleccionar una categoria o crear una!");
							} else {
								try {
									producto.setCodigo(textCodigo.getText().trim());
									producto.setNombre(textNombre.getText().trim());
									producto.setTipoVenta(tipoDeVenta);
									
									// PRECIO COSTO
									String costoTXT = textPrecioCosto.getText().trim();
									Double precioCosto = 0.0;
									boolean aux = false;
									for (int i = 0; i<costoTXT.length(); i++) {
										if (costoTXT.charAt(i) == ',') {
											String precioNuevo = costoTXT.replace(",", ".");
											precioCosto = Double.parseDouble(precioNuevo);
											aux = true;
										}
									}								
									if (aux == true) {
										producto.setPrecioCosto(precioCosto);
									} else {
										precioCosto = Double.parseDouble(costoTXT);
										producto.setPrecioCosto(precioCosto);
									}
									
									// GANANCIA
									String gananciaTXT = textGanancias.getText().trim();
									Double ganancia = 0.0;
									boolean aux2 = false;
									for (int i = 0; i<gananciaTXT.length(); i++) {
										if (gananciaTXT.charAt(i) == ',') {
											String precioNuevo = gananciaTXT.replace(",", ".");
											ganancia = Double.parseDouble(precioNuevo);
											aux2 = true;
										}
									}								
									if (aux2 == true) {
										producto.setGananciaPorcentaje(ganancia);
									} else {
										ganancia = Double.parseDouble(gananciaTXT);
										producto.setGananciaPorcentaje(ganancia);
									}
									
									// PRECIO VENTA
									String precioTXT = textPrecioVenta.getText().trim();
									Double precioVenta = 0.0;
									boolean aux3 = false;
									for (int i = 0; i<precioTXT.length(); i++) {
										if (precioTXT.charAt(i) == ',') {
											String precioNuevo = precioTXT.replace(",", ".");
											precioVenta = Double.parseDouble(precioNuevo);
											aux3 = true;
										}
									}								
									if (aux3 == true) {
										producto.setPrecioVenta(precioVenta);
									} else {
										precioVenta = Double.parseDouble(precioTXT);
										producto.setPrecioVenta(precioVenta);
									}
									
									//
									idCategoria();
									producto.setCategoria(obtenerIdCategoriaCombo);
									
									if (isInt(textStock.getText().trim())) {
										producto.setCantidad(Integer.valueOf(textStock.getText().trim()));
									} else {
										producto.setCantidad(0);
									}
									
									producto.setExento(exento);
									producto.setPorcentajeIva(iva);
									
									if (ctrlProducto.updateProducto(producto, idProducto)) {
										JOptionPane.showMessageDialog(null, "Se ha guardado correctamente el producto.");
										loadTableCategories();
						                clear();
									} else {
										JOptionPane.showMessageDialog(null, "Hubo un error al intentar guardar el producto.");
									}
								} catch (Exception e1) {
									
								}
							}
						} else {
							JOptionPane.showMessageDialog(null, "Ya existe un producto registrado con ese c�digo!");
						}
					} else {
						
					}
				}
			}
		});*/
		btnNewButton.setBackground(new Color(0, 255, 153));
		btnNewButton.setFont(new Font("Lucida Sans", Font.BOLD, 16));
		btnNewButton.setBounds(10, 11, 173, 49);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("ELIMINAR");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Ctrl_Producto controlProducto = new Ctrl_Producto();
		        if (idProducto == 0) {
		            JOptionPane.showMessageDialog(null, "�Seleccione un Producto!");
		        } else {
		            if (!controlProducto.deleteProducto(idProducto)) {
		                JOptionPane.showMessageDialog(null, "�Producto Eliminado!");
		                loadTableCategories();
		                clear();
		            } else {
		                JOptionPane.showMessageDialog(null, "�Error al eliminar producto!");
		            }
		        }
			}
		});
		btnNewButton_1.setBackground(new Color(255, 102, 102));
		btnNewButton_1.setFont(new Font("Lucida Sans", Font.BOLD, 16));
		btnNewButton_1.setBounds(10, 65, 173, 49);
		panel_1.add(btnNewButton_1);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel.setBounds(10, 39, 677, 303);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 657, 281);
		panel.add(scrollPane);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(InternalGestorProducto.class.getResource("/images/Fondo5.png")));
		lblNewLabel.setBounds(0, 0, 900, 475);
		getContentPane().add(lblNewLabel);
	}
	
	/*
	 * Method showing all categories
	 * 
	 * 
	 */
	
	String descripcionCategoria = "";
	private JCheckBox chckbxUnitario;
	private JCheckBox chckbxKilogramos;
	private JCheckBox chckbxExento;
	
	@SuppressWarnings("unchecked")
	public void loadAllCategories() {
            Connection con = SQL.conectar();
		String sql = "select * from tb_categoria";
		Statement st;
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				comboBox.addItem(rs.getString("descripcion"));
			}
			con.close();
		} catch (SQLException e) {
			System.out.print("[J3Studios] � Error al cargar las categorias.");
		}
	}
	
	private void loadTableCategories() {
		Connection con = SQL.conectar();
		DefaultTableModel model = new DefaultTableModel();
		String sql = "select p.idProducto, p.codigo, p.nombre, p.tipoVenta, p.precioCosto, p.gananciaPorcentaje, p.precioVenta, c.descripcion, p.cantidad, p.exento, p.porcentajeIva from tb_producto As p, tb_categoria As c where p.categoria = c.idCategoria;";
        Statement st;
		
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			InternalGestorProducto.table = new JTable(model);
			InternalGestorProducto.scrollPane.setViewportView(InternalGestorProducto.table);
			
			model.addColumn("N�");//ID
            model.addColumn("Codigo");
            model.addColumn("Nombre");
            model.addColumn("Tipo de Venta");
            model.addColumn("Precio de Costo");
            model.addColumn("Ganancia");
            model.addColumn("Precio de Venta");
            model.addColumn("Categor�a");
            model.addColumn("Cantidad/Stock");
            model.addColumn("Exento");
            model.addColumn("IVA");
			
			while(rs.next()) {
                Object fila[] = new Object[11];
				for (int i = 0; i < 11; i++) {
					fila[i] = rs.getObject(i + 1);
				}
				model.addRow(fila);
			}
			con.close();
			
			table.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					Integer fila_point = table.rowAtPoint(e.getPoint());
					Integer columna_point = 0;
					
					if (fila_point >= -1) {
						idProducto = (Integer)model.getValueAt(fila_point, columna_point);
						EnviarDatosProductoSeleccionado(idProducto);
					} 
				}

			});
		} catch (SQLException e) {
			System.out.print("Error al llenar la tabla de productos.");
			System.out.print(e);
		}
	}
	
	private void clear() {
		textCodigo.setText("");
		textNombre.setText("");
    	chckbxKilogramos.setSelected(false);
    	chckbxUnitario.setSelected(false);
    	textPrecioCosto.setText("");
    	textGanancias.setText("");
    	textPrecioVenta.setText("");
        comboBox.setSelectedItem(comboBox.getItemAt(0));
        textStock.setText("");
        chckbxExento.setSelected(false);
        textEditIva.setText("");
	}
	
	private void EnviarDatosProductoSeleccionado(int idProducto) {
        try {
            Connection con = SQL.conectar();
            PreparedStatement pst = con.prepareStatement(
                    "select * from tb_producto where idProducto = '" + idProducto + "'");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
            	
            	textCodigo.setText(rs.getString("codigo"));
            	textNombre.setText(rs.getString("nombre"));
            	if (rs.getString("tipoVenta").equals("UNITARIO")) {
            		chckbxUnitario.setSelected(true);
            		chckbxKilogramos.setSelected(false);
            	} else {
            		chckbxKilogramos.setSelected(true);
            		chckbxUnitario.setSelected(false);
            	}
            	textPrecioCosto.setText(new DecimalFormat("#0.00").format(rs.getDouble("precioCosto")));
            	textGanancias.setText(new DecimalFormat("#0.00").format(rs.getDouble("gananciaPorcentaje")));
            	textPrecioVenta.setText(new DecimalFormat("#0.00").format(rs.getDouble("precioVenta")));
                            	
                int idCate = rs.getInt("categoria");
                comboBox.setSelectedItem(relacionarCategoria(idCate));
                
                textStock.setText(String.valueOf(rs.getInt("cantidad")));
                if (rs.getBoolean("exento")) {
                	chckbxExento.setSelected(true);
                } else {
                	chckbxExento.setSelected(false);
                }
                textEditIva.setText(String.valueOf(rs.getInt("porcentajeIva")));
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al seleccionar producto: " + e);
        }
    }
	
	private String relacionarCategoria(int idCategoria) {
        String sql = "select descripcion from tb_categoria where idCategoria = '" + idCategoria + "'";
        Statement st;
        try {
            Connection cn = SQL.conectar();
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                descripcionCategoria = rs.getString("descripcion");
            }
            cn.close();

        } catch (SQLException e) {
            System.out.println("�Error al obtener el id de la categoria!");
        }
        return descripcionCategoria;
    }
	
	private int idCategoria() {
        String sql = "select * from tb_categoria where descripcion = '" + this.comboBox.getSelectedItem() + "'";
        Statement st;
        try {
            Connection cn = SQL.conectar();
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                obtenerIdCategoriaCombo = rs.getInt("idCategoria");
            }
        } catch (SQLException e) {
            System.out.println("Error al obener id categoria");
        }
        return obtenerIdCategoriaCombo;
    }
	
	public boolean isInt(String s) {
	    try {
	        Integer.parseInt(s);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
	
	public boolean isDouble(String s) {
	    try {
	        Double.parseDouble(s);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
	
	public Double calcPercent (Double value, Double percent) {
		double impuestos = -(100-percent);
    	double calculo = (value * (100 + (impuestos)) / 100);
    	return calculo;
	}

}
