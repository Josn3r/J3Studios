package club.j3studios.system.utils.jtable;

public interface TableActionEvent {
   public void onEdit(int row);
   public void onDelete(int row);
}