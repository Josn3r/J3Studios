package club.j3studios.system.utils;

public interface SearchOptinEvent {
    public void optionSelected(SearchOption option, int index);
}